Fixes #{issue number}
