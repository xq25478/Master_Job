 Hybrid Frontend Tutorials
 -------------------------
 
1. learning_hybrid_frontend_through_example_tutorial.py
	Learning Hybrid Frontend Through Example
	https://pytorch.org/tutorials/beginner/hybrid_frontend/learning_hybrid_frontend_through_example_tutorial.html

2. introduction_to_hybrid_frontend_tutorial.py
	Introduction to Hybrid Frontend
	https://pytorch.org/tutorials/beginner/hybrid_frontend/introduction_to_hybrid_frontend_tutorial.html
