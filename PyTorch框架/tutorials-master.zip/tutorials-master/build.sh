# TODO: make sure pytorch installed
pip install -r requirements.txt
make docs
