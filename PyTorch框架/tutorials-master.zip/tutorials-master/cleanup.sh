rm -rf __pycache__/ _build/ advanced/ beginner/ intermediate/
